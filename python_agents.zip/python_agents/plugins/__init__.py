"""Plugins module"""

from plugins.logging_plugin import LoggingPlugin

__all__ = ["LoggingPlugin"]